/**
 * Notification Helper for handling browser notifications
 * With enhanced support for iOS devices
 */
const NotificationHelper = {
    // Store iOS-specific flags
    isIOS: /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream,
    usePushAPI: false,
    useServiceWorkerNotification: false,
    
    /**
     * Check if notifications are supported and permission granted
     * @returns {Boolean} - Whether notifications can be used
     */
    canUseNotifications: function() {
        // Check for standard notification support
        const standardNotifications = 'Notification' in window && Notification.permission === 'granted';
        
        // Check for iOS-specific notification support
        const iOSNotifications = this.isIOS && (this.usePushAPI || this.useServiceWorkerNotification);
        
        return standardNotifications || iOSNotifications;
    },
    
    /**
     * Request notification permission
     * @returns {Promise} - Resolves with permission status
     */
    requestPermission: function() {
        return new Promise((resolve, reject) => {
            if (!('Notification' in window)) {
                console.log('Notifications not supported');
                
                // Display iOS-specific instructions if on iOS
                if (this.isIOS) {
                    // Store that we need to use alternative notification methods
                    this.useServiceWorkerNotification = true;
                    
                    // Show iOS-specific notification instructions
                    this.showIOSNotificationInstructions();
                    
                    // We'll resolve as if granted since we're using our alternative
                    resolve('ios-fallback');
                } else {
                    resolve('not-supported');
                }
                return;
            }
            
            Notification.requestPermission()
                .then(permission => {
                    // If on iOS and permission denied, show instructions for alternatives
                    if (this.isIOS && permission !== 'granted') {
                        this.useServiceWorkerNotification = true;
                        this.showIOSNotificationInstructions();
                        resolve('ios-fallback');
                    } else {
                        resolve(permission);
                    }
                })
                .catch(error => {
                    console.error('Error requesting notification permission:', error);
                    
                    // If on iOS, fall back to alternative notification method
                    if (this.isIOS) {
                        this.useServiceWorkerNotification = true;
                        this.showIOSNotificationInstructions();
                        resolve('ios-fallback');
                    } else {
                        reject(error);
                    }
                });
        });
    },
    
    /**
     * Show instructions for iOS users about notifications
     */
    showIOSNotificationInstructions: function() {
        // Create the instruction modal if it doesn't exist
        if (!document.getElementById('ios-notification-instructions')) {
            const instructionsModal = document.createElement('div');
            instructionsModal.id = 'ios-notification-instructions';
            instructionsModal.className = 'modal ios-instructions-modal';
            
            instructionsModal.innerHTML = `
                <div class="modal-content">
                    <h2>Enable Notifications on iOS</h2>
                    <p>For the best experience with Daily Scheduler on your iOS device:</p>
                    <ol>
                        <li>Add this app to your home screen (tap the share icon and select "Add to Home Screen")</li>
                        <li>Launch the app from your home screen icon</li>
                        <li>Make sure you have allowed notifications in your device settings</li>
                    </ol>
                    <p>This will ensure you receive timely reminders for your tasks.</p>
                    <button id="close-ios-instructions" class="btn btn-primary">Got it</button>
                </div>
            `;
            
            document.body.appendChild(instructionsModal);
            
            // Add event listener to close button
            document.getElementById('close-ios-instructions').addEventListener('click', () => {
                instructionsModal.style.display = 'none';
            });
        }
        
        // Show the instructions
        document.getElementById('ios-notification-instructions').style.display = 'block';
    },
    
    /**
     * Show notification for a task
     * @param {Object} task - The task to show notification for
     */
    showNotification: function(task) {
        if (!this.canUseNotifications()) {
            console.log('Cannot show notification, permission not granted');
            return;
        }
        
        // Use the task category as the icon
        let icon;
        if (task.category === 'work') {
            icon = 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/briefcase.svg';
        } else if (task.category === 'personal') {
            icon = 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/user.svg';
        } else if (task.category === 'health') {
            icon = 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/heart.svg';
        } else {
            icon = 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/bell.svg';
        }
        
        // Handle iOS-specific notification limitations
        if (this.isIOS && this.useServiceWorkerNotification) {
            // For iOS, we'll use a more visible in-app notification
            this.showIOSInAppNotification(task);
            
            // If service worker is active, try to show notification through it
            if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                console.log('Using service worker to show notification on iOS');
                
                // Create a message channel for communication
                const messageChannel = new MessageChannel();
                
                // Set up response handler
                messageChannel.port1.onmessage = (event) => {
                    console.log('Service worker response:', event.data);
                    
                    if (event.data.success) {
                        console.log('Successfully sent notification through service worker');
                    } else {
                        console.warn('Failed to send notification through service worker, falling back');
                        // In case of failure, we already have the in-app notification as fallback
                    }
                };
                
                // Send the message with the task data
                navigator.serviceWorker.controller.postMessage({
                    type: 'SHOW_NOTIFICATION',
                    task: task,
                    icon: icon
                }, [messageChannel.port2]);
            }
        } else {
            // Standard web notification for other browsers
            const notification = new Notification('Task Reminder', {
                body: task.title,
                icon: icon,
                tag: `task-${task.id}`,
                requireInteraction: true
            });
            
            // Handle notification click
            notification.onclick = () => {
                window.focus();
                notification.close();
                
                // Highlight the task
                UI.highlightTask(task.id);
            };
        }
        
        // Play a sound for all devices
        this.playNotificationSound();
    },
    
    /**
     * Show an in-app notification for iOS devices
     * @param {Object} task - The task to show notification for
     */
    showIOSInAppNotification: function(task) {
        // Create the notification container if it doesn't exist
        if (!document.getElementById('ios-in-app-notification')) {
            const notificationContainer = document.createElement('div');
            notificationContainer.id = 'ios-in-app-notification';
            notificationContainer.className = 'ios-notification';
            document.body.appendChild(notificationContainer);
        }
        
        const container = document.getElementById('ios-in-app-notification');
        
        // Create the notification element
        const notification = document.createElement('div');
        notification.className = 'ios-notification-item';
        notification.dataset.taskId = task.id;
        
        // Add category-specific icon class
        let iconClass = 'fa-bell';
        if (task.category === 'work') {
            iconClass = 'fa-briefcase';
        } else if (task.category === 'personal') {
            iconClass = 'fa-user';
        } else if (task.category === 'health') {
            iconClass = 'fa-heart';
        }
        
        // Format the notification HTML
        notification.innerHTML = `
            <div class="notification-icon">
                <i class="fas ${iconClass}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">Task Reminder</div>
                <div class="notification-body">${task.title}</div>
            </div>
            <div class="notification-close">
                <i class="fas fa-times"></i>
            </div>
        `;
        
        // Add to container
        container.appendChild(notification);
        
        // Add click handler to show the task
        notification.addEventListener('click', function(e) {
            // Ignore if clicking close button
            if (e.target.closest('.notification-close')) {
                return;
            }
            
            const taskId = parseInt(this.dataset.taskId);
            UI.highlightTask(taskId);
            
            // Close the notification
            this.remove();
        });
        
        // Add close button handler
        notification.querySelector('.notification-close').addEventListener('click', function() {
            notification.remove();
        });
        
        // Auto-dismiss after 10 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.classList.add('closing');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 500);
            }
        }, 10000);
    },
    
    /**
     * Play a notification sound
     */
    playNotificationSound: function() {
        try {
            // Use the Web Audio API
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(587.33, audioContext.currentTime); // D5
            
            gainNode.gain.setValueAtTime(0.5, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 1);
        } catch (error) {
            console.error('Error playing notification sound:', error);
        }
    },
    
    /**
     * Schedule a notification for a task
     * @param {Object} task - The task to schedule notification for
     */
    scheduleNotification: function(task) {
        if (!this.canUseNotifications()) {
            console.log('Cannot schedule notification, permission not granted');
            return;
        }
        
        // Get the time to schedule
        const taskTime = new Date(task.dateTime);
        
        // Only schedule if the task is in the future
        if (taskTime > new Date()) {
            const timeUntilNotification = taskTime.getTime() - Date.now();
            
            // Schedule the notification
            setTimeout(() => {
                // Check if the task still exists and is not completed
                DB.getTaskById(task.id).then(currentTask => {
                    if (currentTask && !currentTask.completed) {
                        this.showNotification(currentTask);
                    }
                }).catch(error => {
                    console.error('Error checking task for notification:', error);
                });
            }, timeUntilNotification);
            
            console.log(`Notification scheduled for ${task.title} at ${taskTime}`);
        }
    },
    
    /**
     * Schedule notifications for all upcoming tasks
     */
    scheduleAllNotifications: function() {
        if (!this.canUseNotifications()) {
            console.log('Cannot schedule notifications, permission not granted');
            return;
        }
        
        // Get upcoming tasks for the next 7 days
        DB.getUpcomingTasks(7).then(tasks => {
            // Filter out completed tasks
            const pendingTasks = tasks.filter(task => !task.completed);
            
            // Schedule notifications
            pendingTasks.forEach(task => {
                this.scheduleNotification(task);
            });
            
            console.log(`Scheduled notifications for ${pendingTasks.length} tasks`);
        }).catch(error => {
            console.error('Error scheduling notifications:', error);
        });
    },
    
    /**
     * Initialize the notification system
     */
    init: function() {
        // Check for iOS device first
        if (this.isIOS) {
            console.log('iOS device detected, using iOS-specific notification handling');
            
            // Add iOS notification styles if they don't exist
            if (!document.getElementById('ios-notification-styles')) {
                const styleElement = document.createElement('style');
                styleElement.id = 'ios-notification-styles';
                styleElement.textContent = `
                    .ios-notification {
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        z-index: 9999;
                        padding: 10px;
                        pointer-events: none;
                    }
                    
                    .ios-notification-item {
                        background: rgba(0, 0, 0, 0.8);
                        backdrop-filter: blur(10px);
                        -webkit-backdrop-filter: blur(10px);
                        border-radius: 12px;
                        margin-bottom: 8px;
                        padding: 12px 16px;
                        color: white;
                        display: flex;
                        align-items: center;
                        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                        animation: slideInDown 0.3s ease-out;
                        pointer-events: auto;
                        max-width: 450px;
                        margin-left: auto;
                        margin-right: auto;
                    }
                    
                    .ios-notification-item.closing {
                        animation: slideOutUp 0.5s ease-in forwards;
                    }
                    
                    .notification-icon {
                        width: 30px;
                        height: 30px;
                        background: #007AFF;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-right: 12px;
                        flex-shrink: 0;
                    }
                    
                    .notification-content {
                        flex-grow: 1;
                    }
                    
                    .notification-title {
                        font-weight: bold;
                        font-size: 14px;
                    }
                    
                    .notification-body {
                        font-size: 13px;
                        margin-top: 2px;
                    }
                    
                    .notification-close {
                        padding: 5px;
                        margin-left: 8px;
                        cursor: pointer;
                    }
                    
                    @keyframes slideInDown {
                        from {
                            transform: translateY(-100%);
                            opacity: 0;
                        }
                        to {
                            transform: translateY(0);
                            opacity: 1;
                        }
                    }
                    
                    @keyframes slideOutUp {
                        from {
                            transform: translateY(0);
                            opacity: 1;
                        }
                        to {
                            transform: translateY(-100%);
                            opacity: 0;
                        }
                    }
                    
                    .ios-instructions-modal .modal-content {
                        max-width: 400px;
                        border-radius: 13px;
                        padding: 20px;
                    }
                    
                    .ios-instructions-modal h2 {
                        text-align: center;
                        margin-bottom: 15px;
                    }
                    
                    .ios-instructions-modal ol {
                        margin-left: 20px;
                        margin-bottom: 15px;
                    }
                    
                    .ios-instructions-modal li {
                        margin-bottom: 8px;
                    }
                    
                    .ios-instructions-modal button {
                        width: 100%;
                        padding: 12px;
                        border-radius: 10px;
                        background: #007AFF;
                        color: white;
                        font-weight: bold;
                        border: none;
                        margin-top: 10px;
                    }
                `;
                document.head.appendChild(styleElement);
            }
            
            // Setup Service Worker message handling for notifications 
            if (navigator.serviceWorker) {
                navigator.serviceWorker.addEventListener('message', (event) => {
                    console.log('Received message from service worker:', event.data);
                    
                    if (event.data && event.data.type === 'NOTIFICATION_CLICKED') {
                        const taskId = event.data.taskId;
                        if (taskId) {
                            console.log('Highlighting task from notification click:', taskId);
                            UI.highlightTask(taskId);
                        }
                    }
                    else if (event.data && event.data.type === 'NOTIFICATION_ACTION') {
                        const taskId = event.data.taskId;
                        const action = event.data.action;
                        
                        console.log(`Handling notification action: ${action} for task ${taskId}`);
                        
                        if (action === 'complete' && taskId) {
                            // Mark the task as completed
                            DB.markTaskCompleted(taskId, true)
                                .then(() => {
                                    // Refresh task display
                                    const currentDate = UI.getSelectedDate();
                                    UI.renderTasks(currentDate);
                                    UI.updateProgressStats(currentDate);
                                })
                                .catch(error => {
                                    console.error('Error completing task:', error);
                                });
                        } 
                        else if (action === 'snooze' && taskId) {
                            // Get the task and update the time
                            DB.getTaskById(taskId)
                                .then(task => {
                                    if (!task) return;
                                    
                                    // Create a new time 30 minutes later
                                    const [hours, minutes] = task.time.split(':');
                                    const taskDate = new Date();
                                    taskDate.setHours(parseInt(hours));
                                    taskDate.setMinutes(parseInt(minutes) + 30);
                                    
                                    // Update task time
                                    const newHours = String(taskDate.getHours()).padStart(2, '0');
                                    const newMinutes = String(taskDate.getMinutes()).padStart(2, '0');
                                    task.time = `${newHours}:${newMinutes}`;
                                    
                                    return DB.updateTask(task);
                                })
                                .then(() => {
                                    // Refresh task display
                                    const currentDate = UI.getSelectedDate();
                                    UI.renderTasks(currentDate);
                                    
                                    // Schedule the new notification
                                    this.scheduleAllNotifications();
                                })
                                .catch(error => {
                                    console.error('Error snoozing task:', error);
                                });
                        }
                    }
                    else if (event.data && event.data.type === 'NOTIFICATION_SHOWN') {
                        console.log('Notification shown confirmation from service worker:', event.data);
                    }
                    else if (event.data && event.data.type === 'INIT_IOS_PUSH_RESPONSE') {
                        console.log('Service worker initialized iOS push notifications:', event.data);
                    }
                });
                
                // Register with the service worker for handling notifications
                if (navigator.serviceWorker.controller) {
                    console.log('Initializing iOS push notifications with service worker');
                    navigator.serviceWorker.controller.postMessage({
                        type: 'INIT_IOS_PUSH'
                    });
                }
                
                // Mark that we're using service worker for notifications
                this.useServiceWorkerNotification = true;
            }
            
            // On iOS, we'll always schedule notifications using our custom approach
            setTimeout(() => {
                this.scheduleAllNotifications();
            }, 2000);
            
            return;
        }
        
        // Non-iOS browsers - standard approach
        if (!('Notification' in window)) {
            console.log('Notifications not supported in this browser');
            return;
        }
        
        // Check existing permission
        if (Notification.permission === 'granted') {
            console.log('Notification permission already granted');
            this.scheduleAllNotifications();
        } else if (Notification.permission !== 'denied') {
            // Show notification permission modal
            document.getElementById('notification-modal').style.display = 'block';
            
            // Handle enable button click
            document.getElementById('enable-notifications').addEventListener('click', () => {
                this.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        this.scheduleAllNotifications();
                    }
                    document.getElementById('notification-modal').style.display = 'none';
                }).catch(error => {
                    console.error('Error requesting notification permission:', error);
                    document.getElementById('notification-modal').style.display = 'none';
                });
            });
            
            // Handle skip button click
            document.getElementById('skip-notifications').addEventListener('click', () => {
                document.getElementById('notification-modal').style.display = 'none';
            });
        }
    }
};
