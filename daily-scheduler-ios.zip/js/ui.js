/**
 * UI Helper for rendering and managing the user interface
 */
const UI = {
    // Store the currently selected date
    selectedDate: null,
    
    // Store motivational quotes
    quotes: [
        "Focus on progress, not perfection.",
        "The key to success is to start before you're ready.",
        "You don't have to be great to start, but you have to start to be great.",
        "Small progress is still progress.",
        "Your future is created by what you do today.",
        "Don't count the days, make the days count.",
        "The best way to predict the future is to create it.",
        "Productivity is never an accident. It's the result of a commitment to excellence.",
        "Today is your opportunity to build the tomorrow you want.",
        "Action is the foundational key to all success.",
        "Focus on being productive instead of busy.",
        "Don't wait for the perfect moment, take the moment and make it perfect.",
        "Done is better than perfect.",
        "The way to get started is to quit talking and begin doing.",
        "Your time is limited, don't waste it living someone else's life."
    ],
    
    /**
     * Initialize the UI
     */
    init: function() {
        // Set the selected date to today
        this.selectedDate = this.getFormattedDate(new Date());
        
        // Show a random quote
        this.showRandomQuote();
        
        // Render the calendar
        this.renderCalendar();
        
        // Render tasks for today
        this.renderTasks(this.selectedDate);
        
        // Update progress stats
        this.updateProgressStats(this.selectedDate);
        
        // Setup event listeners
        this.setupEventListeners();
    },
    
    /**
     * Set up all event listeners
     */
    setupEventListeners: function() {
        // Add task button
        document.getElementById('add-task-button').addEventListener('click', () => {
            this.openTaskModal();
        });
        
        // Task form submission
        document.getElementById('task-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleTaskFormSubmit();
        });
        
        // Close modal button
        document.querySelectorAll('.close-button').forEach(button => {
            button.addEventListener('click', () => {
                document.getElementById('task-modal').style.display = 'none';
            });
        });
        
        // Calendar navigation buttons
        document.getElementById('prev-week').addEventListener('click', () => {
            this.navigateCalendar(-1);
        });
        
        document.getElementById('next-week').addEventListener('click', () => {
            this.navigateCalendar(1);
        });
        
        // Task filter buttons
        document.querySelectorAll('.filter-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                this.filterTasks(e.target.dataset.filter);
            });
        });
        
        // Focus mode toggle
        document.getElementById('focus-mode-toggle').addEventListener('click', () => {
            this.toggleFocusMode();
        });
        
        // Modal close when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === document.getElementById('task-modal')) {
                document.getElementById('task-modal').style.display = 'none';
            }
        });
    },
    
    /**
     * Show a random motivational quote
     */
    showRandomQuote: function() {
        const quoteText = document.getElementById('quote-text');
        const randomIndex = Math.floor(Math.random() * this.quotes.length);
        quoteText.textContent = this.quotes[randomIndex];
    },
    
    /**
     * Render the calendar view
     */
    renderCalendar: function() {
        // Calculate the current month view
        const currentDate = this.selectedDate ? new Date(this.selectedDate) : new Date();
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        
        // Set the month title
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                           'July', 'August', 'September', 'October', 'November', 'December'];
        document.getElementById('current-month').textContent = `${monthNames[month]} ${year}`;
        
        // Get dates with tasks for this month
        DB.getDatesWithTasksInMonth(year, month).then(datesWithTasks => {
            // Get the first day of the month
            const firstDay = new Date(year, month, 1);
            const startingDay = firstDay.getDay(); // 0 for Sunday, 1 for Monday, etc.
            
            // Calculate days in month
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            
            // Get the container
            const calendarDays = document.getElementById('calendar-days');
            calendarDays.innerHTML = '';
            
            // Add empty cells for days before the start of the month
            for (let i = 0; i < startingDay; i++) {
                const emptyDay = document.createElement('div');
                emptyDay.className = 'calendar-day empty';
                calendarDays.appendChild(emptyDay);
            }
            
            // Add cells for each day of the month
            for (let i = 1; i <= daysInMonth; i++) {
                const dayCell = document.createElement('div');
                dayCell.className = 'calendar-day';
                dayCell.textContent = i;
                
                // Format the date for comparison
                const dateString = this.getFormattedDate(new Date(year, month, i));
                
                // Check if this day is today
                if (this.isToday(new Date(year, month, i))) {
                    dayCell.classList.add('today');
                }
                
                // Check if this is the selected date
                if (dateString === this.selectedDate) {
                    dayCell.classList.add('selected');
                }
                
                // Check if this day has tasks
                if (datesWithTasks.includes(i)) {
                    dayCell.classList.add('has-tasks');
                }
                
                // Add click handler
                dayCell.addEventListener('click', () => {
                    this.selectDate(dateString);
                });
                
                calendarDays.appendChild(dayCell);
            }
        }).catch(error => {
            console.error('Error rendering calendar:', error);
        });
    },
    
    /**
     * Navigate the calendar by months
     * @param {Number} direction - Direction to navigate (-1 for prev, 1 for next)
     */
    navigateCalendar: function(direction) {
        const currentDate = new Date(this.selectedDate);
        const newMonth = currentDate.getMonth() + direction;
        
        currentDate.setMonth(newMonth);
        this.selectedDate = this.getFormattedDate(currentDate);
        
        this.renderCalendar();
        this.renderTasks(this.selectedDate);
        this.updateProgressStats(this.selectedDate);
    },
    
    /**
     * Select a date and update the UI
     * @param {String} dateString - Date in YYYY-MM-DD format
     */
    selectDate: function(dateString) {
        this.selectedDate = dateString;
        
        // Update the task list title
        const date = new Date(dateString);
        const options = { weekday: 'long', month: 'long', day: 'numeric' };
        document.getElementById('task-list-date').textContent = date.toLocaleDateString('en-US', options);
        
        // Re-render the calendar and tasks
        this.renderCalendar();
        this.renderTasks(dateString);
        this.updateProgressStats(dateString);
    },
    
    /**
     * Get the currently selected date
     * @returns {String} Date in YYYY-MM-DD format
     */
    getSelectedDate: function() {
        return this.selectedDate;
    },
    
    /**
     * Render tasks for a specific date
     * @param {String} date - Date in YYYY-MM-DD format
     * @param {String} category - Optional category to filter by
     */
    renderTasks: function(date, category = 'all') {
        const taskList = document.getElementById('task-list');
        taskList.innerHTML = '';
        
        // Get the active filter button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === category) {
                btn.classList.add('active');
            }
        });
        
        // Get tasks for the date
        DB.getTasksByCategory(category, date).then(tasks => {
            if (tasks.length === 0) {
                const emptyMessage = document.createElement('li');
                emptyMessage.className = 'task-empty-message';
                emptyMessage.textContent = 'No tasks for this day. Add one!';
                taskList.appendChild(emptyMessage);
                return;
            }
            
            // Sort tasks by time
            tasks.sort((a, b) => {
                return new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`);
            });
            
            // Render each task
            tasks.forEach(task => {
                const taskItem = document.createElement('li');
                taskItem.className = 'task-item';
                taskItem.dataset.id = task.id;
                
                if (task.completed) {
                    taskItem.classList.add('completed');
                }
                
                // Check if this is the current/upcoming task
                const taskTime = new Date(`${task.date}T${task.time}`);
                const now = new Date();
                const isCurrentTask = !task.completed && taskTime <= now && taskTime.getDate() === now.getDate();
                
                if (isCurrentTask) {
                    taskItem.classList.add('current-task');
                }
                
                // Format time
                const timeFormatted = this.formatTime(task.time);
                
                // Check if we're on iOS for additional buttons
                const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
                
                // Basic task HTML structure
                let taskHTML = `
                    <div class="task-checkbox ${task.completed ? 'checked' : ''}" data-id="${task.id}">
                        ${task.completed ? '<i class="fas fa-check"></i>' : ''}
                    </div>
                    <div class="task-content">
                        <div class="task-title">${task.title}</div>
                        <div class="task-time">
                            <span class="task-category ${task.category}">${task.category}</span>
                            ${timeFormatted}
                        </div>
                    </div>
                    <div class="task-actions">
                        <button class="task-action-btn edit-task" data-id="${task.id}" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="task-action-btn delete-task" data-id="${task.id}" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                `;
                
                // Add iOS-specific action buttons if on iOS
                if (isIOS) {
                    taskHTML += `
                        <button class="task-action-btn share-task" data-id="${task.id}" title="Share">
                            <i class="fas fa-share-alt"></i>
                        </button>
                        <button class="task-action-btn calendar-task" data-id="${task.id}" title="Add to Calendar">
                            <i class="fas fa-calendar-plus"></i>
                        </button>
                    `;
                }
                
                // Close the task actions div
                taskHTML += `</div>`;
                
                // Set the HTML
                taskItem.innerHTML = taskHTML;
                
                taskList.appendChild(taskItem);
            });
            
            // Add event listeners for task actions
            this.addTaskEventListeners();
        }).catch(error => {
            console.error('Error rendering tasks:', error);
            taskList.innerHTML = '<li class="task-empty-message">Error loading tasks</li>';
        });
    },
    
    /**
     * Add event listeners to task items
     */
    addTaskEventListeners: function() {
        // Task checkbox click
        document.querySelectorAll('.task-checkbox').forEach(checkbox => {
            checkbox.addEventListener('click', (e) => {
                const taskId = parseInt(e.currentTarget.dataset.id);
                const isChecked = e.currentTarget.classList.contains('checked');
                
                // Toggle the checked state
                DB.markTaskCompleted(taskId, !isChecked).then(() => {
                    // Update the UI
                    this.renderTasks(this.selectedDate, document.querySelector('.filter-btn.active').dataset.filter);
                    this.updateProgressStats(this.selectedDate);
                }).catch(error => {
                    console.error('Error marking task as completed:', error);
                });
            });
        });
        
        // Edit task button click
        document.querySelectorAll('.edit-task').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.currentTarget.dataset.id);
                this.editTask(taskId);
            });
        });
        
        // Delete task button click
        document.querySelectorAll('.delete-task').forEach(button => {
            button.addEventListener('click', (e) => {
                const taskId = parseInt(e.currentTarget.dataset.id);
                this.deleteTask(taskId);
            });
        });
        
        // iOS-specific: Share task button (only if Web Share API is available)
        if (navigator.share) {
            document.querySelectorAll('.share-task').forEach(button => {
                button.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const taskId = parseInt(e.currentTarget.dataset.id);
                    
                    try {
                        // Get the task details
                        const task = await DB.getTaskById(taskId);
                        if (!task) return;
                        
                        // Format date for display
                        const date = new Date(task.date);
                        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                        const formattedDate = date.toLocaleDateString('en-US', dateOptions);
                        
                        // Format share data
                        const shareData = {
                            title: 'Daily Scheduler Task',
                            text: `${task.title} - ${formattedDate} at ${this.formatTime(task.time)} (${task.category})`,
                            url: window.location.href
                        };
                        
                        // Use Web Share API
                        await navigator.share(shareData);
                        console.log('Task shared successfully');
                    } catch (error) {
                        console.error('Error sharing task:', error);
                        if (error.name !== 'AbortError') {
                            // Only show error if not user cancellation
                            alert('Could not share this task. Please try again.');
                        }
                    }
                });
            });
        }
        
        // iOS-specific: Add to Calendar button
        document.querySelectorAll('.calendar-task').forEach(button => {
            button.addEventListener('click', async (e) => {
                e.stopPropagation();
                const taskId = parseInt(e.currentTarget.dataset.id);
                
                try {
                    // Get the task details
                    const task = await DB.getTaskById(taskId);
                    if (!task) return;
                    
                    if (window.iOSHelper && typeof window.iOSHelper.addTaskToCalendar === 'function') {
                        // Use our iOS helper to create the calendar event
                        window.iOSHelper.addTaskToCalendar(taskId);
                    } else {
                        // Fallback method using .ics file download
                        const [year, month, day] = task.date.split('-');
                        const [hours, minutes] = task.time.split(':');
                        
                        // Create start date
                        const startDate = new Date(year, month - 1, day, hours, minutes);
                        
                        // Create end date (1 hour after start)
                        const endDate = new Date(startDate);
                        endDate.setHours(endDate.getHours() + 1);
                        
                        // Format dates for iCal
                        const formatDate = (date) => {
                            return date.toISOString().replace(/-|:|\.\d+/g, '');
                        };
                        
                        // Create iCal file content
                        const icalContent = [
                            'BEGIN:VCALENDAR',
                            'VERSION:2.0',
                            'BEGIN:VEVENT',
                            `SUMMARY:${task.title}`,
                            `DTSTART:${formatDate(startDate)}`,
                            `DTEND:${formatDate(endDate)}`,
                            `DESCRIPTION:${task.category} task from Daily Scheduler app`,
                            'STATUS:CONFIRMED',
                            'END:VEVENT',
                            'END:VCALENDAR'
                        ].join('\n');
                        
                        // Create a downloadable .ics file
                        const blob = new Blob([icalContent], { type: 'text/calendar;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = `${task.title.replace(/\s+/g, '_')}.ics`;
                        
                        // Trigger download
                        link.click();
                        
                        // Clean up
                        setTimeout(() => URL.revokeObjectURL(url), 100);
                    }
                } catch (error) {
                    console.error('Error adding task to calendar:', error);
                    alert('Could not add task to calendar. Please try again.');
                }
            });
        });
    },
    
    /**
     * Filter tasks by category
     * @param {String} category - Category to filter by
     */
    filterTasks: function(category) {
        // Update active filter button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === category) {
                btn.classList.add('active');
            }
        });
        
        // Re-render tasks with the filter
        this.renderTasks(this.selectedDate, category);
    },
    
    /**
     * Update progress statistics
     * @param {String} date - Date to get stats for
     */
    updateProgressStats: function(date) {
        DB.getTaskStats(date).then(stats => {
            const progressBar = document.getElementById('progress-bar');
            const progressText = document.getElementById('progress-text');
            
            // Update progress bar
            progressBar.style.width = `${stats.progress}%`;
            
            // Update text
            progressText.textContent = `${stats.completed}/${stats.total} tasks completed`;
        }).catch(error => {
            console.error('Error updating progress stats:', error);
        });
    },
    
    /**
     * Open the task modal for adding a new task
     */
    openTaskModal: function() {
        // Reset the form
        document.getElementById('task-form').reset();
        document.getElementById('task-id').value = '';
        document.getElementById('modal-title').textContent = 'Add New Task';
        
        // Set the date to the selected date
        document.getElementById('task-date').value = this.selectedDate;
        
        // Show the modal
        document.getElementById('task-modal').style.display = 'block';
    },
    
    /**
     * Open the task modal for editing an existing task
     * @param {Number} taskId - ID of the task to edit
     */
    editTask: function(taskId) {
        DB.getTaskById(taskId).then(task => {
            if (!task) {
                console.error('Task not found');
                return;
            }
            
            // Set form values
            document.getElementById('task-id').value = task.id;
            document.getElementById('task-title').value = task.title;
            document.getElementById('task-date').value = task.date;
            document.getElementById('task-time').value = task.time;
            document.getElementById('task-category').value = task.category;
            document.getElementById('task-repeat').value = task.repeat || 'none';
            
            // Update modal title
            document.getElementById('modal-title').textContent = 'Edit Task';
            
            // Show the modal
            document.getElementById('task-modal').style.display = 'block';
        }).catch(error => {
            console.error('Error loading task for editing:', error);
        });
    },
    
    /**
     * Delete a task
     * @param {Number} taskId - ID of the task to delete
     */
    deleteTask: function(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            DB.deleteTask(taskId).then(() => {
                // Update the UI
                this.renderTasks(this.selectedDate, document.querySelector('.filter-btn.active').dataset.filter);
                this.updateProgressStats(this.selectedDate);
                this.renderCalendar(); // Re-render calendar to update task indicators
            }).catch(error => {
                console.error('Error deleting task:', error);
            });
        }
    },
    
    /**
     * Handle task form submission
     */
    handleTaskFormSubmit: function() {
        // Get form values
        const taskId = document.getElementById('task-id').value;
        const title = document.getElementById('task-title').value;
        const date = document.getElementById('task-date').value;
        const time = document.getElementById('task-time').value;
        const category = document.getElementById('task-category').value;
        const repeat = document.getElementById('task-repeat').value;
        
        // Create task object
        const task = {
            title,
            date,
            time,
            category,
            repeat: repeat !== 'none' ? repeat : null,
            completed: false
        };
        
        // Add or update the task
        if (taskId) {
            // Update existing task
            task.id = parseInt(taskId);
            
            DB.updateTask(task).then(() => {
                // Close the modal
                document.getElementById('task-modal').style.display = 'none';
                
                // Update the UI
                this.renderTasks(this.selectedDate, document.querySelector('.filter-btn.active').dataset.filter);
                this.updateProgressStats(this.selectedDate);
                this.renderCalendar(); // Re-render calendar to update task indicators
            }).catch(error => {
                console.error('Error updating task:', error);
            });
        } else {
            // Add new task
            DB.addTask(task).then(() => {
                // Close the modal
                document.getElementById('task-modal').style.display = 'none';
                
                // Update the UI
                this.renderTasks(this.selectedDate, document.querySelector('.filter-btn.active').dataset.filter);
                this.updateProgressStats(this.selectedDate);
                this.renderCalendar(); // Re-render calendar to update task indicators
            }).catch(error => {
                console.error('Error adding task:', error);
            });
        }
    },
    
    /**
     * Toggle focus mode
     */
    toggleFocusMode: function() {
        const body = document.body;
        body.classList.toggle('focus-mode');
        
        // Save the focus mode state
        DB.saveSetting('focusMode', body.classList.contains('focus-mode'));
        
        // Update the button icon
        const button = document.getElementById('focus-mode-toggle');
        if (body.classList.contains('focus-mode')) {
            button.innerHTML = '<i class="fas fa-eye"></i>';
            button.title = 'Exit Focus Mode';
            
            // Show notification in focus mode
            if (NotificationHelper.canUseNotifications()) {
                new Notification('Focus Mode Enabled', {
                    body: 'You will only receive notifications for your current task.',
                    icon: 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/svgs/solid/focus.svg'
                });
            }
        } else {
            button.innerHTML = '<i class="fas fa-focus"></i>';
            button.title = 'Focus Mode';
        }
    },
    
    /**
     * Highlight a specific task
     * @param {Number} taskId - ID of the task to highlight
     */
    highlightTask: function(taskId) {
        // Find the task item
        const taskItem = document.querySelector(`.task-item[data-id="${taskId}"]`);
        
        if (taskItem) {
            // Scroll to the task if needed
            taskItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Add highlight class
            taskItem.classList.add('highlighted');
            
            // Remove highlight after a few seconds
            setTimeout(() => {
                taskItem.classList.remove('highlighted');
            }, 3000);
        }
    },
    
    /**
     * Format a time string for display
     * @param {String} timeString - Time in HH:MM format
     * @returns {String} - Formatted time string
     */
    formatTime: function(timeString) {
        const [hours, minutes] = timeString.split(':');
        const hour = parseInt(hours);
        const period = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        
        return `${hour12}:${minutes} ${period}`;
    },
    
    /**
     * Get a formatted date string (YYYY-MM-DD) from a Date object
     * @param {Date} date - The date to format
     * @returns {String} - Formatted date string
     */
    getFormattedDate: function(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}-${month}-${day}`;
    },
    
    /**
     * Check if a date is today
     * @param {Date} date - The date to check
     * @returns {Boolean} - Whether the date is today
     */
    isToday: function(date) {
        const today = new Date();
        
        return date.getDate() === today.getDate() &&
               date.getMonth() === today.getMonth() &&
               date.getFullYear() === today.getFullYear();
    }
};
