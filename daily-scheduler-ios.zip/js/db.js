/**
 * Database management for the Daily Scheduler app
 * Uses IndexedDB for offline storage
 */
const DB = {
    dbName: 'schedulerApp',
    dbVersion: 1,
    db: null,
    
    /**
     * Initialize the database
     */
    init: function() {
        return new Promise((resolve, reject) => {
            // Open connection to IndexedDB
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            // Handle database upgrade (first time or version change)
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create tasks object store
                if (!db.objectStoreNames.contains('tasks')) {
                    const tasksStore = db.createObjectStore('tasks', { keyPath: 'id', autoIncrement: true });
                    tasksStore.createIndex('date', 'date', { unique: false });
                    tasksStore.createIndex('time', 'time', { unique: false });
                    tasksStore.createIndex('category', 'category', { unique: false });
                    tasksStore.createIndex('dateTime', 'dateTime', { unique: false });
                }
                
                // Create settings object store
                if (!db.objectStoreNames.contains('settings')) {
                    const settingsStore = db.createObjectStore('settings', { keyPath: 'id' });
                }
            };
            
            // Handle successful database opening
            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log('Database initialized successfully');
                resolve();
            };
            
            // Handle errors
            request.onerror = (event) => {
                console.error('Database initialization error:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Add a new task to the database
     * @param {Object} task - The task object to add
     * @returns {Promise} - Resolves with the task ID
     */
    addTask: function(task) {
        return new Promise((resolve, reject) => {
            // Calculate dateTime for sorting and notifications
            task.dateTime = new Date(`${task.date}T${task.time}`);
            
            const transaction = this.db.transaction(['tasks'], 'readwrite');
            const store = transaction.objectStore('tasks');
            const request = store.add(task);
            
            request.onsuccess = (event) => {
                const taskId = event.target.result;
                resolve(taskId);
            };
            
            request.onerror = (event) => {
                console.error('Error adding task:', event.target.error);
                reject(event.target.error);
            };
            
            transaction.oncomplete = () => {
                // Schedule notification for the new task
                if (typeof NotificationHelper !== 'undefined') {
                    NotificationHelper.scheduleNotification(task);
                }
            };
        });
    },
    
    /**
     * Update an existing task
     * @param {Object} task - The task object to update
     * @returns {Promise} - Resolves when task is updated
     */
    updateTask: function(task) {
        return new Promise((resolve, reject) => {
            // Calculate dateTime for sorting and notifications
            task.dateTime = new Date(`${task.date}T${task.time}`);
            
            const transaction = this.db.transaction(['tasks'], 'readwrite');
            const store = transaction.objectStore('tasks');
            const request = store.put(task);
            
            request.onsuccess = () => {
                resolve();
            };
            
            request.onerror = (event) => {
                console.error('Error updating task:', event.target.error);
                reject(event.target.error);
            };
            
            transaction.oncomplete = () => {
                // Re-schedule notification for the updated task
                if (typeof NotificationHelper !== 'undefined') {
                    NotificationHelper.scheduleNotification(task);
                }
            };
        });
    },
    
    /**
     * Delete a task by ID
     * @param {Number} id - The task ID to delete
     * @returns {Promise} - Resolves when task is deleted
     */
    deleteTask: function(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readwrite');
            const store = transaction.objectStore('tasks');
            const request = store.delete(id);
            
            request.onsuccess = () => {
                resolve();
            };
            
            request.onerror = (event) => {
                console.error('Error deleting task:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get all tasks
     * @returns {Promise} - Resolves with an array of all tasks
     */
    getAllTasks: function() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Error getting all tasks:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get tasks for a specific date
     * @param {String} date - Date in YYYY-MM-DD format
     * @returns {Promise} - Resolves with an array of tasks for the date
     */
    getTasksByDate: function(date) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            const dateIndex = store.index('date');
            const request = dateIndex.getAll(date);
            
            request.onsuccess = (event) => {
                const tasks = event.target.result;
                // Sort by time
                tasks.sort((a, b) => {
                    return a.dateTime - b.dateTime;
                });
                resolve(tasks);
            };
            
            request.onerror = (event) => {
                console.error('Error getting tasks by date:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get a task by ID
     * @param {Number} id - The task ID
     * @returns {Promise} - Resolves with the task object
     */
    getTaskById: function(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            const request = store.get(id);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Error getting task by ID:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get tasks by category
     * @param {String} category - The category to filter by
     * @param {String} date - Optional date to further filter
     * @returns {Promise} - Resolves with filtered tasks
     */
    getTasksByCategory: function(category, date = null) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            
            // If we have a date, use that to filter first
            let request;
            if (date) {
                const dateIndex = store.index('date');
                request = dateIndex.getAll(date);
            } else {
                request = store.getAll();
            }
            
            request.onsuccess = (event) => {
                let tasks = event.target.result;
                // Filter by category if not "all"
                if (category !== 'all') {
                    tasks = tasks.filter(task => task.category === category);
                }
                // Sort by date and time
                tasks.sort((a, b) => {
                    return a.dateTime - b.dateTime;
                });
                resolve(tasks);
            };
            
            request.onerror = (event) => {
                console.error('Error getting tasks by category:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Mark a task as completed or not completed
     * @param {Number} id - The task ID
     * @param {Boolean} completed - Whether the task is completed
     * @returns {Promise} - Resolves when task is updated
     */
    markTaskCompleted: function(id, completed) {
        return new Promise((resolve, reject) => {
            this.getTaskById(id).then(task => {
                if (!task) {
                    reject(new Error('Task not found'));
                    return;
                }
                
                task.completed = completed;
                task.completedAt = completed ? new Date() : null;
                
                this.updateTask(task).then(resolve).catch(reject);
            }).catch(reject);
        });
    },
    
    /**
     * Get upcoming tasks
     * @param {Number} days - Number of days to look ahead
     * @returns {Promise} - Resolves with upcoming tasks
     */
    getUpcomingTasks: function(days = 7) {
        return new Promise((resolve, reject) => {
            const today = new Date();
            const endDate = new Date();
            endDate.setDate(today.getDate() + days);
            
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                const tasks = event.target.result;
                // Filter tasks within the date range
                const upcomingTasks = tasks.filter(task => {
                    const taskDate = new Date(task.dateTime);
                    return taskDate >= today && taskDate <= endDate;
                });
                
                // Sort by date and time
                upcomingTasks.sort((a, b) => {
                    return a.dateTime - b.dateTime;
                });
                
                resolve(upcomingTasks);
            };
            
            request.onerror = (event) => {
                console.error('Error getting upcoming tasks:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get a setting value
     * @param {String} key - The setting key
     * @param {*} defaultValue - Default value if setting doesn't exist
     * @returns {Promise} - Resolves with the setting value
     */
    getSetting: function(key, defaultValue = null) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readonly');
            const store = transaction.objectStore('settings');
            const request = store.get(key);
            
            request.onsuccess = (event) => {
                const result = event.target.result;
                resolve(result ? result.value : defaultValue);
            };
            
            request.onerror = (event) => {
                console.error('Error getting setting:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Save a setting
     * @param {String} key - The setting key
     * @param {*} value - The setting value
     * @returns {Promise} - Resolves when setting is saved
     */
    saveSetting: function(key, value) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readwrite');
            const store = transaction.objectStore('settings');
            const request = store.put({ id: key, value: value });
            
            request.onsuccess = () => {
                resolve();
            };
            
            request.onerror = (event) => {
                console.error('Error saving setting:', event.target.error);
                reject(event.target.error);
            };
        });
    },
    
    /**
     * Get task statistics for a specific date
     * @param {String} date - Date in YYYY-MM-DD format
     * @returns {Promise} - Resolves with task statistics
     */
    getTaskStats: function(date) {
        return new Promise((resolve, reject) => {
            this.getTasksByDate(date).then(tasks => {
                const total = tasks.length;
                const completed = tasks.filter(task => task.completed).length;
                const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
                
                resolve({
                    total,
                    completed,
                    progress
                });
            }).catch(reject);
        });
    },
    
    /**
     * Get dates that have tasks in a given month
     * @param {Number} year - The year
     * @param {Number} month - The month (0-11)
     * @returns {Promise} - Resolves with array of dates with tasks
     */
    getDatesWithTasksInMonth: function(year, month) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['tasks'], 'readonly');
            const store = transaction.objectStore('tasks');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                const tasks = event.target.result;
                const datesWithTasks = new Set();
                
                // Filter tasks in the given month and collect unique dates
                tasks.forEach(task => {
                    const taskDate = new Date(task.dateTime);
                    if (taskDate.getFullYear() === year && taskDate.getMonth() === month) {
                        const day = taskDate.getDate();
                        datesWithTasks.add(day);
                    }
                });
                
                resolve(Array.from(datesWithTasks));
            };
            
            request.onerror = (event) => {
                console.error('Error getting dates with tasks:', event.target.error);
                reject(event.target.error);
            };
        });
    }
};
