import { db } from "./db";
import { eq, and } from "drizzle-orm";
import { tasks, settings, users, type User, type InsertUser, type Task, type InsertTask } from "../shared/schema";

// Interface for storage operations - matches existing IndexedDB interface
interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // Task methods
  addTask(task: InsertTask): Promise<number>;
  updateTask(task: Task): Promise<void>;
  deleteTask(id: number): Promise<void>;
  getAllTasks(): Promise<Task[]>;
  getTasksByDate(date: string): Promise<Task[]>;
  getTaskById(id: number): Promise<Task | undefined>;
  getTasksByCategory(category: string, date?: string | null): Promise<Task[]>;
  markTaskCompleted(id: number, completed: boolean): Promise<void>;
  getUpcomingTasks(days?: number): Promise<Task[]>;
  
  // Settings methods
  getSetting(key: string, defaultValue?: any): Promise<any>;
  saveSetting(key: string, value: any): Promise<void>;
  
  // Stats
  getTaskStats(date: string): Promise<{total: number, completed: number, progress: number}>;
  getDatesWithTasksInMonth(year: number, month: number): Promise<number[]>;
}

// DatabaseStorage implementation that uses PostgreSQL via Drizzle ORM
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Task methods
  async addTask(task: InsertTask): Promise<number> {
    // Convert dateTime handling to work with PostgreSQL
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask.id;
  }

  async updateTask(task: Task): Promise<void> {
    await db.update(tasks)
      .set(task)
      .where(eq(tasks.id, task.id));
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async getTasksByDate(date: string): Promise<Task[]> {
    const result = await db.select()
      .from(tasks)
      .where(eq(tasks.date, date))
      .orderBy(tasks.time);
    
    return result;
  }

  async getTaskById(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getTasksByCategory(category: string, date: string | null = null): Promise<Task[]> {
    let query = db.select().from(tasks);
    
    // Apply filters based on parameters
    if (date) {
      query = query.where(eq(tasks.date, date));
    }
    
    if (category !== 'all') {
      query = query.where(eq(tasks.category, category));
    }
    
    // Execute query and order results
    const result = await query.orderBy(tasks.date, tasks.time);
    return result;
  }

  async markTaskCompleted(id: number, completed: boolean): Promise<void> {
    const task = await this.getTaskById(id);
    if (!task) {
      throw new Error('Task not found');
    }
    
    await db.update(tasks)
      .set({ 
        completed: completed, 
        completedAt: completed ? new Date() : null 
      })
      .where(eq(tasks.id, id));
  }

  async getUpcomingTasks(days: number = 7): Promise<Task[]> {
    // Get today's date
    const today = new Date();
    const endDate = new Date();
    endDate.setDate(today.getDate() + days);
    
    // Format dates for SQL comparison
    const todayStr = today.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];
    
    // Get all tasks within date range
    const allTasks = await db.select().from(tasks);
    
    // Filter tasks within date range and not completed
    const upcomingTasks = allTasks.filter(task => {
      return task.date >= todayStr && task.date <= endDateStr;
    });
    
    // Sort by date and time
    upcomingTasks.sort((a, b) => {
      if (a.date === b.date) {
        return a.time.localeCompare(b.time);
      }
      return a.date.localeCompare(b.date);
    });
    
    return upcomingTasks;
  }

  // Settings methods
  async getSetting(key: string, defaultValue: any = null): Promise<any> {
    // For now, assume no user authentication, so use userId = 1
    const userId = 1;
    
    const [setting] = await db.select()
      .from(settings)
      .where(and(eq(settings.userId, userId), eq(settings.key, key)));
    
    if (setting) {
      try {
        return JSON.parse(setting.value || '');
      } catch (e) {
        return setting.value;
      }
    }
    
    return defaultValue;
  }

  async saveSetting(key: string, value: any): Promise<void> {
    // For now, assume no user authentication, so use userId = 1
    const userId = 1;
    
    // Convert value to string if needed
    const valueStr = typeof value === 'object' ? JSON.stringify(value) : String(value);
    
    // Check if setting exists
    const [existingSetting] = await db.select()
      .from(settings)
      .where(and(eq(settings.userId, userId), eq(settings.key, key)));
    
    if (existingSetting) {
      // Update existing setting
      await db.update(settings)
        .set({ value: valueStr, updatedAt: new Date() })
        .where(eq(settings.id, existingSetting.id));
    } else {
      // Create new setting
      await db.insert(settings).values({
        userId,
        key,
        value: valueStr
      });
    }
  }

  // Stats methods
  async getTaskStats(date: string): Promise<{total: number, completed: number, progress: number}> {
    const tasks = await this.getTasksByDate(date);
    
    const total = tasks.length;
    const completed = tasks.filter(task => task.completed).length;
    const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    return {
      total,
      completed,
      progress
    };
  }

  async getDatesWithTasksInMonth(year: number, month: number): Promise<number[]> {
    // Convert month (0-based index) to the format used in our dates (1-based)
    const monthStr = (month + 1).toString().padStart(2, '0');
    const yearStr = year.toString();
    
    // Get all tasks in the database
    const allTasks = await db.select().from(tasks);
    
    // Filter tasks in the specified month and year
    const datesWithTasks = new Set<number>();
    
    allTasks.forEach(task => {
      // Extract year and month from task date (YYYY-MM-DD format)
      const [taskYear, taskMonth] = task.date.split('-');
      
      if (taskYear === yearStr && taskMonth === monthStr) {
        // Extract day as a number and add to set
        const day = parseInt(task.date.split('-')[2], 10);
        datesWithTasks.add(day);
      }
    });
    
    return Array.from(datesWithTasks);
  }
}

// Create and export a singleton instance
export const storage = new DatabaseStorage();