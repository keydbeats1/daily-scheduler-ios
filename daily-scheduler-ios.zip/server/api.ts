import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { storage } from './storage';

// Load environment variables
dotenv.config();

// Create Express app
const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'API server is running' });
});

// Tasks endpoints
app.get('/api/tasks', async (req, res) => {
  try {
    const tasks = await storage.getAllTasks();
    res.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

app.get('/api/tasks/date/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const tasks = await storage.getTasksByDate(date);
    res.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks by date:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

app.get('/api/tasks/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const { date } = req.query;
    const tasks = await storage.getTasksByCategory(category, date as string || null);
    res.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks by category:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

app.get('/api/tasks/:id', async (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const task = await storage.getTaskById(taskId);
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    res.json(task);
  } catch (error) {
    console.error('Error fetching task:', error);
    res.status(500).json({ error: 'Failed to fetch task' });
  }
});

app.post('/api/tasks', async (req, res) => {
  try {
    const task = req.body;
    const taskId = await storage.addTask(task);
    
    // Get the created task
    const createdTask = await storage.getTaskById(taskId);
    res.status(201).json(createdTask);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

app.put('/api/tasks/:id', async (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const task = req.body;
    
    // Ensure the ID in the path matches the task object
    task.id = taskId;
    
    await storage.updateTask(task);
    res.json({ message: 'Task updated successfully' });
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
});

app.delete('/api/tasks/:id', async (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    await storage.deleteTask(taskId);
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

app.patch('/api/tasks/:id/complete', async (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const { completed } = req.body;
    
    await storage.markTaskCompleted(taskId, completed);
    res.json({ message: 'Task completion status updated' });
  } catch (error) {
    console.error('Error updating task completion:', error);
    res.status(500).json({ error: 'Failed to update task completion status' });
  }
});

// Stats endpoints
app.get('/api/stats/date/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const stats = await storage.getTaskStats(date);
    res.json(stats);
  } catch (error) {
    console.error('Error fetching task stats:', error);
    res.status(500).json({ error: 'Failed to fetch task statistics' });
  }
});

app.get('/api/stats/month/:year/:month', async (req, res) => {
  try {
    const year = parseInt(req.params.year);
    const month = parseInt(req.params.month);
    const dates = await storage.getDatesWithTasksInMonth(year, month);
    res.json(dates);
  } catch (error) {
    console.error('Error fetching dates with tasks:', error);
    res.status(500).json({ error: 'Failed to fetch dates with tasks' });
  }
});

// Settings endpoints
app.get('/api/settings/:key', async (req, res) => {
  try {
    const { key } = req.params;
    const { defaultValue } = req.query;
    
    const value = await storage.getSetting(key, defaultValue);
    res.json({ key, value });
  } catch (error) {
    console.error('Error fetching setting:', error);
    res.status(500).json({ error: 'Failed to fetch setting' });
  }
});

app.post('/api/settings', async (req, res) => {
  try {
    const { key, value } = req.body;
    
    await storage.saveSetting(key, value);
    res.json({ message: 'Setting saved successfully' });
  } catch (error) {
    console.error('Error saving setting:', error);
    res.status(500).json({ error: 'Failed to save setting' });
  }
});

// Start server
export function startServer() {
  return app.listen(PORT, () => {
    console.log(`API server running on port ${PORT}`);
  });
}

// If this file is run directly (not imported), start the server
if (require.main === module) {
  startServer();
}

export default app;