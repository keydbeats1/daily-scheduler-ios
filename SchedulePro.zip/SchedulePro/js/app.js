/**
 * Main application file for Daily Scheduler
 * Initializes the application and handles core functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the database
    DB.init().then(() => {
        console.log('Database initialized');
        
        // Initialize the UI after database is ready
        UI.init();
        
        // Initialize notifications
        NotificationHelper.init();
        
        // Load focus mode state if saved
        DB.getSetting('focusMode', false).then(focusMode => {
            if (focusMode) {
                document.body.classList.add('focus-mode');
                document.getElementById('focus-mode-toggle').innerHTML = '<i class="fas fa-eye"></i>';
                document.getElementById('focus-mode-toggle').title = 'Exit Focus Mode';
            }
        });
        
        // Check for service worker support
        checkServiceWorkerSupport();
        
        // Add PWA install prompt
        handlePWAInstall();
        
        // Initialize iOS-specific features
        if (window.iOSHelper) {
            window.iOSHelper.initialize();
        }
        
        // Setup pull-to-refresh functionality for iOS
        setupPullToRefresh();
    }).catch(error => {
        console.error('Error initializing database:', error);
        showErrorMessage('Failed to initialize the app. Please refresh the page and try again.');
    });
});

/**
 * Check service worker support and handle initial data
 */
function checkServiceWorkerSupport() {
    if ('serviceWorker' in navigator) {
        // Service worker is supported
        console.log('Service Worker supported');
        
        // Register the event listener for online/offline changes
        window.addEventListener('online', updateOnlineStatus);
        window.addEventListener('offline', updateOnlineStatus);
        
        // Initial check
        updateOnlineStatus();
    } else {
        // Service worker is not supported - limited offline functionality
        console.warn('Service Worker not supported - offline functionality will be limited');
        
        // Show warning for users
        const appContainer = document.querySelector('.app-container');
        const warningEl = document.createElement('div');
        warningEl.className = 'offline-warning';
        warningEl.textContent = 'Limited offline support detected. Some features may not work without internet.';
        appContainer.insertBefore(warningEl, appContainer.firstChild);
    }
}

/**
 * Update UI based on online/offline status
 */
function updateOnlineStatus() {
    const isOnline = navigator.onLine;
    
    // Update UI elements if needed
    if (!isOnline) {
        // Show offline indicator
        if (!document.querySelector('.offline-indicator')) {
            const offlineEl = document.createElement('div');
            offlineEl.className = 'offline-indicator';
            offlineEl.innerHTML = '<i class="fas fa-wifi"></i> Offline Mode';
            document.body.appendChild(offlineEl);
            
            // Animate in
            setTimeout(() => {
                offlineEl.style.transform = 'translateY(0)';
            }, 10);
        }
    } else {
        // Remove offline indicator if exists
        const offlineEl = document.querySelector('.offline-indicator');
        if (offlineEl) {
            offlineEl.style.transform = 'translateY(100%)';
            setTimeout(() => {
                offlineEl.remove();
            }, 300);
        }
    }
}

/**
 * Handle PWA installation
 */
function handlePWAInstall() {
    // Check if device is iOS
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    
    // Show install instruction for iOS users
    if (isIOS && !navigator.standalone) {
        // Check if we've already shown the message
        DB.getSetting('iosInstallShown', false).then(shown => {
            if (!shown) {
                // Create the install instruction element
                const installEl = document.createElement('div');
                installEl.className = 'ios-install-prompt';
                installEl.innerHTML = `
                    <div class="prompt-content">
                        <h3>Install this App</h3>
                        <p>For the best experience, add this app to your home screen:</p>
                        <ol>
                            <li>Tap the share icon <i class="fas fa-share-square"></i></li>
                            <li>Select "Add to Home Screen"</li>
                        </ol>
                        <button id="dismiss-install">Got it</button>
                    </div>
                `;
                
                document.body.appendChild(installEl);
                
                // Handle dismiss button
                document.getElementById('dismiss-install').addEventListener('click', () => {
                    installEl.remove();
                    DB.saveSetting('iosInstallShown', true);
                });
            }
        });
    }
}

/**
 * Show error message to the user
 * @param {String} message - The error message to display
 */
function showErrorMessage(message) {
    const errorEl = document.createElement('div');
    errorEl.className = 'error-message';
    errorEl.textContent = message;
    
    // Add to document
    document.body.appendChild(errorEl);
    
    // Animate in
    setTimeout(() => {
        errorEl.style.transform = 'translateY(0)';
        
        // Remove after a delay
        setTimeout(() => {
            errorEl.style.transform = 'translateY(-100%)';
            setTimeout(() => errorEl.remove(), 300);
        }, 5000);
    }, 10);
}

/**
 * Setup pull-to-refresh functionality (especially useful for iOS)
 */
function setupPullToRefresh() {
    const pullToRefreshEl = document.getElementById('pull-to-refresh');
    const taskListContainer = document.querySelector('.task-list-container');
    
    if (!pullToRefreshEl || !taskListContainer) return;
    
    let touchStartY = 0;
    let touchEndY = 0;
    let refreshing = false;
    
    // Add touch event listeners
    taskListContainer.addEventListener('touchstart', (e) => {
        touchStartY = e.touches[0].clientY;
    }, { passive: true });
    
    taskListContainer.addEventListener('touchmove', (e) => {
        if (refreshing) return;
        
        touchEndY = e.touches[0].clientY;
        const distance = touchEndY - touchStartY;
        
        // If we're at the top of the container and pulling down
        if (taskListContainer.scrollTop === 0 && distance > 0) {
            // Show pull-to-refresh indicator proportional to pull distance
            // but capped at a max height
            const pullHeight = Math.min(distance * 0.5, 60);
            pullToRefreshEl.style.marginTop = `${pullHeight - 60}px`;
            
            if (pullHeight > 40) {
                pullToRefreshEl.classList.add('visible');
            }
            
            // Prevent default scrolling behavior
            e.preventDefault();
        }
    }, { passive: false });
    
    taskListContainer.addEventListener('touchend', () => {
        if (refreshing) return;
        
        const distance = touchEndY - touchStartY;
        
        // If pulled far enough, trigger refresh
        if (taskListContainer.scrollTop === 0 && distance > 60) {
            refreshData();
        } else {
            // Reset pull-to-refresh indicator
            pullToRefreshEl.style.marginTop = '-60px';
            pullToRefreshEl.classList.remove('visible');
        }
    });
    
    /**
     * Refresh data from the database
     */
    function refreshData() {
        refreshing = true;
        pullToRefreshEl.style.marginTop = '0';
        pullToRefreshEl.classList.add('visible');
        
        // Get currently selected date
        const currentDate = UI.getSelectedDate();
        
        // Reload tasks for the current date
        Promise.all([
            DB.getTasksByDate(currentDate),
            DB.getTaskStats(currentDate)
        ]).then(([tasks, stats]) => {
            // Update UI with fresh data
            UI.renderTasks(tasks, currentDate);
            UI.updateProgress(stats);
            
            // Reset pull-to-refresh after a delay
            setTimeout(() => {
                pullToRefreshEl.style.marginTop = '-60px';
                pullToRefreshEl.classList.remove('visible');
                refreshing = false;
            }, 1000);
        }).catch(error => {
            console.error('Error refreshing data:', error);
            showErrorMessage('Failed to refresh data. Please try again.');
            
            // Reset pull-to-refresh
            pullToRefreshEl.style.marginTop = '-60px';
            pullToRefreshEl.classList.remove('visible');
            refreshing = false;
        });
    }
}
