/**
 * iOS Integration Helper
 * Enhances the PWA experience on iOS devices
 */
const iOSHelper = (() => {
    let isIOS = false;
    
    /**
     * Initialize iOS-specific features
     */
    function initialize() {
        // Check if running on iOS
        isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        
        if (isIOS) {
            console.log('Running on iOS - initializing iOS integration');
            setupIOSSpecificUI();
            handleIOSInstallPrompt();
            setupShareFunctionality();
            setupAddToCalendarFunctionality();
            setupPullToRefresh();
            setupHapticFeedback();
            observeColorScheme();
            handleIOSNotificationSetup();
        }
    }
    
    /**
     * Apply iOS-specific UI adjustments
     */
    function setupIOSSpecificUI() {
        document.body.classList.add('ios-device');
        
        // Fix for iOS input zoom on focus
        const viewportMeta = document.querySelector('meta[name="viewport"]');
        if (viewportMeta) {
            viewportMeta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
        }
        
        // Fix for iOS momentum scrolling
        document.querySelectorAll('.task-list-container').forEach(el => {
            el.style.webkitOverflowScrolling = 'touch';
        });
        
        // Apply iOS-specific styling to form inputs
        document.querySelectorAll('input, select').forEach(el => {
            el.classList.add('ios-input');
        });
    }
    
    /**
     * Display a custom install prompt for iOS
     */
    function handleIOSInstallPrompt() {
        // Only show install prompt if not already in standalone mode
        if (!navigator.standalone) {
            // Check if we've already shown the prompt before
            const hasShownPrompt = localStorage.getItem('iosInstallPromptShown');
            
            if (!hasShownPrompt) {
                // Wait a bit before showing the prompt
                setTimeout(() => {
                    const installPrompt = document.createElement('div');
                    installPrompt.className = 'ios-install-prompt';
                    installPrompt.innerHTML = `
                        <div class="prompt-content">
                            <h3>Install This App</h3>
                            <p>For the best experience, add this app to your home screen:</p>
                            <ol>
                                <li>Tap the share icon <i class="fas fa-share-square"></i></li>
                                <li>Select "Add to Home Screen"</li>
                            </ol>
                            <button id="close-prompt" class="btn secondary-btn">Maybe Later</button>
                        </div>
                    `;
                    
                    document.body.appendChild(installPrompt);
                    
                    // Handle close button
                    document.getElementById('close-prompt').addEventListener('click', () => {
                        installPrompt.remove();
                        localStorage.setItem('iosInstallPromptShown', 'true');
                    });
                    
                    // Auto-dismiss after 15 seconds
                    setTimeout(() => {
                        if (document.body.contains(installPrompt)) {
                            installPrompt.remove();
                        }
                    }, 15000);
                }, 5000);
            }
        }
    }
    
    /**
     * Set up Share API integration for iOS
     */
    function setupShareFunctionality() {
        // Add share button to task items if Share API is supported
        if (navigator.share) {
            document.querySelectorAll('.task-item').forEach(taskItem => {
                const taskActions = taskItem.querySelector('.task-actions');
                if (taskActions) {
                    const shareButton = document.createElement('button');
                    shareButton.className = 'task-action-btn share-btn';
                    shareButton.innerHTML = '<i class="fas fa-share-alt"></i>';
                    shareButton.title = 'Share Task';
                    
                    shareButton.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const taskId = taskItem.dataset.id;
                        shareTask(taskId);
                    });
                    
                    taskActions.appendChild(shareButton);
                }
            });
        }
    }
    
    /**
     * Share a task using the Web Share API
     * @param {Number} taskId - ID of the task to share
     */
    async function shareTask(taskId) {
        // Get task from database
        const task = await window.DB.getTaskById(taskId);
        
        if (task) {
            const shareData = {
                title: 'Task: ' + task.title,
                text: `${task.title} - ${task.date} at ${task.time} (${task.category})`,
                url: window.location.href + '?taskId=' + taskId
            };
            
            try {
                await navigator.share(shareData);
                console.log('Task shared successfully');
            } catch (err) {
                console.error('Error sharing task:', err);
            }
        }
    }
    
    /**
     * Add functionality to create calendar events on iOS
     */
    function setupAddToCalendarFunctionality() {
        document.querySelectorAll('.task-item').forEach(taskItem => {
            const taskActions = taskItem.querySelector('.task-actions');
            if (taskActions) {
                const calendarButton = document.createElement('button');
                calendarButton.className = 'task-action-btn calendar-btn';
                calendarButton.innerHTML = '<i class="fas fa-calendar-plus"></i>';
                calendarButton.title = 'Add to Calendar';
                
                calendarButton.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const taskId = taskItem.dataset.id;
                    addTaskToCalendar(taskId);
                });
                
                taskActions.appendChild(calendarButton);
            }
        });
    }
    
    /**
     * Create a calendar event for a task
     * @param {Number} taskId - ID of the task to add to calendar
     */
    async function addTaskToCalendar(taskId) {
        // Get task from database
        const task = await window.DB.getTaskById(taskId);
        
        if (task) {
            // Format date and time for calendar
            const [year, month, day] = task.date.split('-');
            const [hours, minutes] = task.time.split(':');
            
            // Create start date
            const startDate = new Date(year, month - 1, day, hours, minutes);
            
            // Create end date (1 hour after start)
            const endDate = new Date(startDate);
            endDate.setHours(endDate.getHours() + 1);
            
            // Format dates for iCal
            const startISOString = startDate.toISOString().replace(/-|:|\.\d+/g, '');
            const endISOString = endDate.toISOString().replace(/-|:|\.\d+/g, '');
            
            // Create iCal file content
            const icalContent = [
                'BEGIN:VCALENDAR',
                'VERSION:2.0',
                'BEGIN:VEVENT',
                `SUMMARY:${task.title}`,
                `DTSTART:${startISOString}`,
                `DTEND:${endISOString}`,
                `DESCRIPTION:${task.category} task from Daily Scheduler app`,
                'STATUS:CONFIRMED',
                'END:VEVENT',
                'END:VCALENDAR'
            ].join('\n');
            
            // Create a blob from the iCal content
            const blob = new Blob([icalContent], { type: 'text/calendar;charset=utf-8' });
            
            // Create a temporary link element
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `${task.title.replace(/\s+/g, '_')}.ics`;
            
            // Trigger download
            document.body.appendChild(link);
            link.click();
            
            // Clean up
            document.body.removeChild(link);
            setTimeout(() => URL.revokeObjectURL(link.href), 100);
        }
    }
    
    /**
     * Observe and respond to iOS color scheme changes
     */
    function observeColorScheme() {
        // Check if we can use matchMedia
        if (window.matchMedia) {
            const colorSchemeQuery = window.matchMedia('(prefers-color-scheme: dark)');
            
            // Apply initial color scheme
            applyColorScheme(colorSchemeQuery.matches ? 'dark' : 'light');
            
            // Listen for changes
            colorSchemeQuery.addEventListener('change', (e) => {
                applyColorScheme(e.matches ? 'dark' : 'light');
            });
        }
    }
    
    /**
     * Apply color scheme based on iOS setting
     * @param {String} scheme - 'dark' or 'light'
     */
    function applyColorScheme(scheme) {
        const root = document.documentElement;
        
        if (scheme === 'dark') {
            root.classList.add('dark-mode');
            root.classList.remove('light-mode');
        } else {
            root.classList.add('light-mode');
            root.classList.remove('dark-mode');
        }
        
        // Update status bar style
        const metaStatusBar = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
        if (metaStatusBar) {
            metaStatusBar.content = scheme === 'dark' ? 'black' : 'default';
        }
    }
    
    /**
     * Handle incoming share targets (when app is launched via system share sheet)
     */
    function handleShareTarget() {
        // Check if URL contains share parameters
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('share')) {
            const title = urlParams.get('title') || '';
            const text = urlParams.get('text') || '';
            
            // If we have shared content, open task form
            if (title || text) {
                // Extract potential task details from shared content
                const taskTitle = title || text.split('\n')[0] || 'Shared Task';
                
                // Set a slight delay to ensure the app is fully loaded
                setTimeout(() => {
                    // Open the task form
                    const taskForm = document.getElementById('task-form');
                    if (taskForm) {
                        // Try to fill in the form with shared content
                        const titleInput = document.getElementById('task-title');
                        if (titleInput) {
                            titleInput.value = taskTitle;
                        }
                        
                        // Open the modal
                        const taskModal = document.getElementById('task-modal');
                        if (taskModal) {
                            taskModal.style.display = 'block';
                        }
                    }
                }, 1000);
                
                // Clean up URL
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        }
    }
    
    /**
     * Add iOS-specific CSS styles dynamically
     */
    function addIOSStyles() {
        const style = document.createElement('style');
        style.textContent = `
            /* iOS-specific styles */
            .ios-device {
                /* Prevent overscroll bounce effect native to iOS */
                position: fixed;
                width: 100%;
                height: 100%;
                overflow: hidden;
            }
            
            .ios-device .app-container {
                height: 100%;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch; /* Enable momentum scrolling */
            }
            
            /* iOS-style inputs */
            .ios-input {
                -webkit-appearance: none;
                border-radius: var(--border-radius);
                font-size: 16px; /* Prevent zoom on focus */
            }
            
            /* iOS-style install prompt */
            .ios-install-prompt {
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                background-color: var(--card-color);
                border-radius: 12px;
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
                width: 90%;
                max-width: 400px;
                z-index: 1000;
                animation: slideUp 0.3s ease-out;
            }
            
            .ios-install-prompt .prompt-content {
                padding: 16px;
            }
            
            .ios-install-prompt h3 {
                margin-top: 0;
                color: var(--accent-color);
            }
            
            .ios-install-prompt ol {
                margin-left: 20px;
                padding-left: 0;
            }
            
            .ios-install-prompt li {
                margin-bottom: 8px;
            }
            
            @keyframes slideUp {
                from { transform: translate(-50%, 100%); }
                to { transform: translate(-50%, 0); }
            }
            
            /* Safari-specific fixes */
            @supports (-webkit-touch-callout: none) {
                /* Fix for bottom safe area on iPhone X and newer */
                .app-container {
                    padding-bottom: env(safe-area-inset-bottom, 20px);
                }
                
                /* Fix for top safe area on iPhone X and newer */
                header {
                    padding-top: env(safe-area-inset-top, 20px);
                }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    /**
     * Setup pull-to-refresh functionality (especially useful for iOS)
     */
    function setupPullToRefresh() {
        // Get the main container that will have pull-to-refresh
        const taskListContainer = document.querySelector('.task-list-container');
        if (!taskListContainer) return;
        
        // Variables for tracking pull state
        let startY = 0;
        let currentY = 0;
        let isPulling = false;
        let pullThreshold = 80; // How far (in px) user needs to pull down to trigger refresh
        
        // Create the pull-to-refresh UI elements
        const pullIndicator = document.createElement('div');
        pullIndicator.className = 'pull-indicator';
        pullIndicator.innerHTML = `
            <div class="pull-spinner">
                <i class="fas fa-sync-alt"></i>
            </div>
            <div class="pull-text">Pull down to refresh...</div>
        `;
        taskListContainer.prepend(pullIndicator);
        
        // Add pull-to-refresh styles
        const style = document.createElement('style');
        style.textContent = `
            .pull-indicator {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 60px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                transform: translateY(-100%);
                transition: transform 0.2s ease;
                z-index: 5;
                background-color: var(--app-background);
            }
            
            .pull-spinner {
                height: 30px;
                width: 30px;
                border-radius: 50%;
                background: var(--accent-color);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                margin-bottom: 5px;
            }
            
            .pull-spinner i {
                font-size: 16px;
            }
            
            .pull-spinner.spinning i {
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            .pull-text {
                font-size: 12px;
                color: var(--text-color);
            }
            
            /* Make room for iOS safe areas */
            @supports (padding-top: env(safe-area-inset-top)) {
                .pull-indicator {
                    padding-top: env(safe-area-inset-top);
                    height: calc(60px + env(safe-area-inset-top));
                }
            }
        `;
        document.head.appendChild(style);
        
        // Track touch/pointer events for pull detection
        taskListContainer.addEventListener('touchstart', (e) => {
            // Only enable pull if at top of the container
            if (taskListContainer.scrollTop <= 0) {
                startY = e.touches[0].clientY;
                currentY = startY;
                isPulling = true;
            }
        }, { passive: true });
        
        taskListContainer.addEventListener('touchmove', (e) => {
            if (!isPulling) return;
            
            currentY = e.touches[0].clientY;
            const pullDistance = Math.max(0, currentY - startY);
            
            // Apply resistance - the further they pull, the harder it gets
            const resistance = 0.4;
            const pullOffset = Math.min(pullDistance * resistance, pullThreshold);
            
            if (pullOffset > 0) {
                // Only prevent default when we're actually pulling
                // This is crucial for iOS to prevent its bounce effect but allow normal scrolling
                if (taskListContainer.scrollTop <= 0) {
                    e.preventDefault();
                }
                
                // Update the UI to show pull progress
                pullIndicator.style.transform = `translateY(${pullOffset - 60}px)`;
                
                // Update the text and icon based on pull progress
                const pullSpinner = pullIndicator.querySelector('.pull-spinner');
                const pullText = pullIndicator.querySelector('.pull-text');
                
                if (pullOffset >= pullThreshold) {
                    pullText.textContent = 'Release to refresh...';
                    pullSpinner.style.transform = 'rotate(180deg)';
                } else {
                    pullText.textContent = 'Pull down to refresh...';
                    pullSpinner.style.transform = 'rotate(0deg)';
                }
            }
        }, { passive: false }); // We need passive: false to be able to use preventDefault
        
        // Handle touch end - either trigger refresh or cancel
        taskListContainer.addEventListener('touchend', (e) => {
            if (!isPulling) return;
            
            const pullDistance = Math.max(0, currentY - startY);
            const resistance = 0.4;
            const pullOffset = Math.min(pullDistance * resistance, pullThreshold);
            
            isPulling = false;
            
            if (pullOffset >= pullThreshold) {
                // User pulled enough to trigger refresh
                refreshData();
            } else {
                // Not pulled enough, reset the UI
                pullIndicator.style.transform = 'translateY(-100%)';
            }
        });
        
        // Function to handle the actual data refresh
        function refreshData() {
            const pullSpinner = pullIndicator.querySelector('.pull-spinner');
            const pullText = pullIndicator.querySelector('.pull-text');
            
            // Update UI to show loading
            pullText.textContent = 'Refreshing...';
            pullSpinner.classList.add('spinning');
            
            // Get the current date from UI helper
            const currentDate = window.UI.getSelectedDate();
            
            // Refresh data with a small delay to show the animation
            setTimeout(async () => {
                try {
                    // Re-render tasks for the current date
                    window.UI.renderTasks(currentDate);
                    
                    // Re-render calendar to show any updates
                    window.UI.renderCalendar();
                    
                    // Update progress stats
                    window.UI.updateProgressStats(currentDate);
                    
                    // Show success message
                    pullText.textContent = 'Successfully updated!';
                    pullSpinner.classList.remove('spinning');
                    pullSpinner.innerHTML = '<i class="fas fa-check"></i>';
                    
                    // Hide the indicator after a short delay
                    setTimeout(() => {
                        pullIndicator.style.transform = 'translateY(-100%)';
                        // Reset the spinner after it's hidden
                        setTimeout(() => {
                            pullSpinner.innerHTML = '<i class="fas fa-sync-alt"></i>';
                        }, 300);
                    }, 1500);
                } catch (error) {
                    console.error('Error refreshing data:', error);
                    
                    // Show error message
                    pullText.textContent = 'Failed to update. Try again.';
                    pullSpinner.classList.remove('spinning');
                    pullSpinner.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
                    
                    // Hide the indicator after a short delay
                    setTimeout(() => {
                        pullIndicator.style.transform = 'translateY(-100%)';
                        // Reset the spinner after it's hidden
                        setTimeout(() => {
                            pullSpinner.innerHTML = '<i class="fas fa-sync-alt"></i>';
                        }, 300);
                    }, 1500);
                }
            }, 1000);
        }
    }
    
    /**
     * Handle iOS-specific notification setup and permissions
     */
    function handleIOSNotificationSetup() {
        // Check if running as installed PWA for better notification support
        if (window.navigator.standalone) {
            console.log('Running as installed PWA on iOS - enabling enhanced notification support');
            
            // Set up service worker message handling for notifications
            if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                // Initialize iOS push notifications via service worker
                navigator.serviceWorker.controller.postMessage({
                    type: 'INIT_IOS_PUSH'
                });
                
                // Listen for notification messages from service worker
                navigator.serviceWorker.addEventListener('message', (event) => {
                    console.log('Message from service worker:', event.data);
                    
                    if (event.data.type === 'NOTIFICATION_CLICKED') {
                        const taskId = event.data.taskId;
                        if (taskId && window.UI && window.UI.highlightTask) {
                            triggerHapticFeedback('notification');
                            window.UI.highlightTask(taskId);
                        }
                    }
                    else if (event.data.type === 'NOTIFICATION_ACTION') {
                        if (event.data.action === 'complete' && event.data.taskId) {
                            // Mark task as complete
                            triggerHapticFeedback('success');
                            window.DB.markTaskCompleted(event.data.taskId, true)
                                .then(() => {
                                    const currentDate = window.UI.getSelectedDate();
                                    window.UI.renderTasks(currentDate);
                                    window.UI.updateProgressStats(currentDate);
                                })
                                .catch(error => {
                                    console.error('Error completing task:', error);
                                });
                        }
                        else if (event.data.action === 'snooze' && event.data.taskId) {
                            // Snooze logic
                            // Show a snooze prompt or automatically reschedule
                            triggerHapticFeedback('warning');
                            window.DB.getTaskById(event.data.taskId)
                                .then(task => {
                                    if (!task) return;
                                    
                                    // Create a new time 30 minutes later
                                    const [hours, minutes] = task.time.split(':');
                                    const taskDate = new Date();
                                    taskDate.setHours(parseInt(hours));
                                    taskDate.setMinutes(parseInt(minutes) + 30);
                                    
                                    // Update task with new time
                                    const newHours = String(taskDate.getHours()).padStart(2, '0');
                                    const newMinutes = String(taskDate.getMinutes()).padStart(2, '0');
                                    
                                    task.time = `${newHours}:${newMinutes}`;
                                    
                                    // Save the updated task
                                    return window.DB.updateTask(task);
                                })
                                .then(() => {
                                    // Refresh the UI
                                    const currentDate = window.UI.getSelectedDate();
                                    window.UI.renderTasks(currentDate);
                                    window.UI.updateProgressStats(currentDate);
                                    
                                    // Reschedule notifications
                                    if (window.NotificationHelper) {
                                        window.NotificationHelper.scheduleAllNotifications();
                                    }
                                })
                                .catch(error => {
                                    console.error('Error snoozing task:', error);
                                });
                        }
                    }
                });
            }
        }
    }
    
    /**
     * Trigger haptic feedback on iOS devices
     * @param {String} type - Type of haptic feedback: 'light', 'medium', 'heavy', 'success', 'warning', 'error', 'notification'
     */
    function triggerHapticFeedback(type = 'light') {
        // Check if vibration API is supported
        if ('vibrate' in navigator) {
            // Different vibration patterns for different feedback types
            switch(type) {
                case 'light':
                    navigator.vibrate(10);
                    break;
                case 'medium':
                    navigator.vibrate(20);
                    break;
                case 'heavy':
                    navigator.vibrate(30);
                    break;
                case 'success':
                    navigator.vibrate([10, 30, 10]);
                    break;
                case 'warning':
                    navigator.vibrate([30, 50, 30]);
                    break;
                case 'error':
                    navigator.vibrate([50, 30, 50, 30, 50]);
                    break;
                case 'notification':
                    navigator.vibrate([10, 20, 10, 20, 10]);
                    break;
                default:
                    navigator.vibrate(15);
            }
        }
    }
    
    /**
     * Set up haptic feedback for common interface elements
     */
    function setupHapticFeedback() {
        // Only setup haptic feedback on iOS
        if (!isIOS) return;
        
        console.log('Setting up haptic feedback for iOS');

        // Add haptic feedback to buttons
        document.addEventListener('click', (e) => {
            const target = e.target.closest('button, .btn, .task-item, .calendar-day');
            
            if (target) {
                // Different feedback for different UI elements
                if (target.classList.contains('task-item')) {
                    triggerHapticFeedback('light');
                } 
                else if (target.classList.contains('calendar-day')) {
                    triggerHapticFeedback('light');
                }
                else if (target.classList.contains('primary-btn') || target.classList.contains('btn-primary')) {
                    triggerHapticFeedback('medium');
                }
                else if (target.classList.contains('complete-action') || target.closest('.complete-action')) {
                    triggerHapticFeedback('success');
                }
                else if (target.classList.contains('delete-action') || target.closest('.delete-action')) {
                    triggerHapticFeedback('error');
                }
                else {
                    triggerHapticFeedback('light');
                }
            }
        });
        
        // Add haptic feedback to form submissions
        document.addEventListener('submit', () => {
            triggerHapticFeedback('success');
        });
        
        // Add haptic feedback to toggle switches
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                triggerHapticFeedback('medium');
            });
        });
    }
    
    // Public API
    return {
        initialize,
        shareTask,
        addTaskToCalendar,
        handleShareTarget,
        setupPullToRefresh,
        triggerHapticFeedback
    };
})();

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    iOSHelper.initialize();
    iOSHelper.handleShareTarget();
    
    // Add iOS-specific styles
    const style = document.createElement('style');
    style.textContent = `
        /* iOS-specific styles */
        .ios-device {
            /* Prevent overscroll bounce effect native to iOS */
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        
        .ios-device .app-container {
            height: 100%;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch; /* Enable momentum scrolling */
        }
        
        /* iOS-style inputs */
        .ios-input {
            -webkit-appearance: none;
            border-radius: var(--border-radius);
            font-size: 16px; /* Prevent zoom on focus */
        }
        
        /* iOS-style install prompt */
        .ios-install-prompt {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--card-color);
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 400px;
            z-index: 1000;
            animation: slideUp 0.3s ease-out;
        }
        
        .ios-install-prompt .prompt-content {
            padding: 16px;
        }
        
        .ios-install-prompt h3 {
            margin-top: 0;
            color: var(--accent-color);
        }
        
        .ios-install-prompt ol {
            margin-left: 20px;
            padding-left: 0;
        }
        
        .ios-install-prompt li {
            margin-bottom: 8px;
        }
        
        @keyframes slideUp {
            from { transform: translate(-50%, 100%); }
            to { transform: translate(-50%, 0); }
        }
        
        /* Safari-specific fixes */
        @supports (-webkit-touch-callout: none) {
            /* Fix for bottom safe area on iPhone X and newer */
            .app-container {
                padding-bottom: env(safe-area-inset-bottom, 20px);
            }
            
            /* Fix for top safe area on iPhone X and newer */
            header {
                padding-top: env(safe-area-inset-top, 20px);
            }
        }
    `;
    
    document.head.appendChild(style);
});

// Expose iOS helper to window for use in other scripts
window.iOSHelper = iOSHelper;